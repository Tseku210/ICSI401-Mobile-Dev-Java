package com.example.HelloConstraint;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private int mCount = 0;
    private TextView mShowCount;
    private Button zeroBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mShowCount = (TextView) findViewById(R.id.show_count);
        zeroBtn = (Button) findViewById(R.id.button_zero);
    }

    public void showToast(View view) {
        Toast toast = Toast.makeText(this, R.string.toast_message,
                Toast.LENGTH_SHORT);
        toast.show();
    }

    public void countUp(View view) {
        mCount++;

        // if zero button not 0 change color
        if (mCount != 0) {
            zeroBtn.setBackgroundColor(this.getResources().getColor(R.color.teal_200));
        }

        // change color based on odd or even number
        if (mCount % 2 == 0) {
            view.setBackgroundColor(this.getResources().getColor(R.color.purple_200));
        } else {
            view.setBackgroundColor(this.getResources().getColor(R.color.purple_500));
        }

        if (mShowCount != null) {
            mShowCount.setText(Integer.toString(mCount));
        }
    }

    public void setZero(View view) {
        mCount = 0;

        view.setBackgroundColor(this.getResources().getColor(R.color.gray));

        if (mShowCount != null) {
            mShowCount.setText(Integer.toString(mCount));
        }
    }
}